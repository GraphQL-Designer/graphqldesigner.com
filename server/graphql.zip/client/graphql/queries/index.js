import { gql } from 'apollo-boost';

const queryEveryAuthor = gql`
	{
		authors {
			id
			name
			age
		}
	}
`

const queryAuthorById = gql`
	query($id: ID) {
		author(id: $id) {
			id
			name
			age
		}
	}
`

export { queryEveryAuthor, queryAuthorById  };