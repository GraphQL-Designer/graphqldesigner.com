import { gql } from 'apollo-boost';

const addAuthorMutation = gql`
	mutation($name: String!, $age: Number!) {
		addBook(name: $name, age: $age) {
			id
			name
			age
		}
	}
`

export { addAuthorMutation };