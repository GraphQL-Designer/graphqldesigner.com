const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const authorSchema = new Schema({
	name: [{
		type: String,
		unique: false,
		required: true
	}],
	age: [{
		type: Number,
		unique: false,
		required: true
	}]
});

module.exports = mongoose.model("Author", authorSchema);